# Magic Values(Input Types):
- broadcasts: 11
- text: 10 eg. say
- number: 4 eg. operator
- boolean: 2 (hidden when empty) eg. not
- look into scratch wiki "file format"

# Missing Features:
- procedures
- more block opcodes

# TODO
EXPLORE AND MAYBE TRANSLATE EXTENSIONDATA
maybe rename assets and put into folder structure
maybe remove "sampleCount"
maybe translate currentValue for cetain types
ADD OTHER MONITOR TYPES

layerOrder: highest is in front
back is 1 for sprites. stage always =0
