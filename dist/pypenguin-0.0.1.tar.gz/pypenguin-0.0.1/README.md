# PyPenguin
Python tool for creating, editing and inspecting Penguinmod(.pmp) files.

### [Documetation](DOCUMENTATION.md)
