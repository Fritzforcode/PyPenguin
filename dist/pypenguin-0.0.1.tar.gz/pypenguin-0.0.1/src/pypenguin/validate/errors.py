class ValidationError(Exception):
    pass